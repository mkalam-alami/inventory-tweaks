|==============================================================|
| INVENTORY TWEAKS Mod - By Jimeo Wan (jimeo.wan at gmail.com) |
| Readme                                                       |
| �bersetz von AJFire                                          |
|==============================================================|

========= [ SETUP ] =========

1. Stelle sicher, dass der ModLoader bereits installiert ist (http://www.minecraftforum.net/topic/75440-)
2. Entferne �ltere Versionen von dem Inventory Tweak-Mods
3. Lege die .zip-Datei in den "mods"-Ordner deiner Minecraft Installation
4. Starte das Spiel!

======= [ BENUTZUNG ] =======

* Die Standart-Taste f�r die Sortierung ist R, du kannst die Taste in den Optionen von Minecraft �ndern. Die Mittlere Maustaste funktioniert auch.
* Beim ersten Start werden Zwei Konfigurations-Datein im Root-Ordner von Minecraft angelegt. �ffne diese, um zu lernen, wie man diesen Mod verwendet.

========= [ LINKS ] =========

* Minecraft Forum thread: http://www.minecraftforum.net/topic/323444-
* Official website: http://wan.ka.free.fr/?invtweaks
* Source code: https://github.com/jimeowan/inventory-tweaks